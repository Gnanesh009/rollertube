export {default as Singup} from './Auth/Signup/SignUp'
export {default as Login} from './Auth/Login/Login'
export {default as Home} from './home/HomeScreen'
export {default as ResetPassword} from './Auth/Resetpassword/resetPassword'
export {default as BottomNav} from '../components/bottommenu/bottomMenu';