import React from 'react'

const CustomButton=()=>{
    return <div>Button</div>
}

export default CustomButton