import React, { Component } from 'react'


import { useEffect,useState } from 'react'


export  const useFetch=()=>{

    const [data,setData]=useState();

    useEffect(()=>{
        // fetch()

    },[])
    return data

}